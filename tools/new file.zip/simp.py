

class Simp(object):
    flag = False

    def adding(self, a, b):
        """Author: Maor Maharizi,
                        Created: 01.02.2023,
                        Detail: calc sum of 2 numbers
                        Return: sum"""
        Simp.flag = True
        return a + b

    def subtracting(self, a, b):
        """Author: Maor Maharizi,
                        Created: 01.02.2023,
                        Detail: calc subtracting of 2 numbers
                        Return: subtracting"""
        Simp.flag = True
        return a - b